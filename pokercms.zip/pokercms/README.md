# poker-cms
### 1. 依赖模块
    pip install requests PyExecJS pillow

### 3. 接口调用
    from pokercms import cmsapi
    # 查询待审核转账提案
    result = cmsapi.getBuyinList()
